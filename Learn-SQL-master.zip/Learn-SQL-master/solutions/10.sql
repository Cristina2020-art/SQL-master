SELECT AVG(length) as 'Average Song Duration'
FROM songs;