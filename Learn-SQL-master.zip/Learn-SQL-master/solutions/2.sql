SELECT bands.name AS 'Band Name'
FROM bands;